package com.example.finalexam.utils;

import java.io.Serializable;

/**
 * Created by mshehab on 5/6/18.
 */

public class Person implements Serializable {
    public String name;
    public int totalBudget;
    public int totalBought;
    public int giftCount;
    String id;

    public Person() {
    }
}
