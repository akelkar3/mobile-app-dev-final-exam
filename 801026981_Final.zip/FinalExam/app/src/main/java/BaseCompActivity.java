import android.support.v7.app.AppCompatActivity;

/**
 * Created by Aliandro on 5/7/2018.
 */

public class BaseCompActivity extends AppCompatActivity {

}
